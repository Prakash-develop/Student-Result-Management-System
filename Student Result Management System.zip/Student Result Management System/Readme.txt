Hi Guys....
This is my Project video demo 

Now I'm Creating on  Student Result Management System(SRMS)

--------> How to Run a Student Result Management System using PHP and MySql <--------------

step 1:Download and Install Xampp (or) Wamp (or) Lamp Server for your Operating bites . But I Perferably Xampp Server

step 2: Download the Source code for SRMS in Github.Com

step 3: Extract the file and copy the folder alpharoon

step 4: Paste the  root Directory( for xampp/htdocs, for wamp/www , for lamp/www/html )

step 5: Open the Xampp server and Start the Apache and MYSQL Server

step 6: Open your Browser and type ( http://localhoast/dashbord ) and click on phpMyAdmin for your top on right side

step 7: Create a database with new name alpharoon and Import alpharoon.sql file ( given inside of Zip file in SQL file folder)

step 8: Run the Script ( http://localhost/alpharoon/ )


-----Admin----- 
user name: admin
password: admin

----Students (for demo)-----
roll id : 1017014
class : Ten

roll id :1217010
class :Twelve








 